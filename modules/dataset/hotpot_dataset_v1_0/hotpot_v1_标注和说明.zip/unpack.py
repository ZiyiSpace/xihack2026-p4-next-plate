"""Unpack only the manifest-listed PNG files, checking every SHA-256."""
import json,hashlib,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def main():
    rows=[json.loads(s) for s in (ROOT/'observations.jsonl').read_text(encoding='utf-8').splitlines() if s.strip()]
    hashes={r['sample_id']:r['sha256'] for r in json.loads((ROOT/'image_manifest.json').read_text(encoding='utf-8'))}
    count=0
    for r in rows:
        relative=Path(r['image_path'])
        if relative.is_absolute() or '..' in relative.parts or relative.parts[0]!='images':raise ValueError('Unsafe image path')
        p=ROOT/relative;expected=hashes[r['sample_id']]
        if p.exists():
            if hashlib.sha256(p.read_bytes()).hexdigest()!=expected:raise ValueError('Existing file differs; not overwriting: '+str(relative))
            continue
        with zipfile.ZipFile(ROOT/'archives'/f"{r['dish_id']}.zip") as z:data=z.read(r['image_path'])
        if hashlib.sha256(data).hexdigest()!=expected:raise ValueError('Checksum mismatch: '+str(relative))
        p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);count+=1
    print('Images ready. Extracted '+str(count)+' files. Run python3 validate.py, then open preview.html.')
if __name__=='__main__':main()
