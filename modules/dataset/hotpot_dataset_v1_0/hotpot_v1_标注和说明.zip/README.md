# 旋转小火锅多模态合成数据集 v1.0

六种菜品，每种10条，共60张AI生成图片与60条模拟重量观测。覆盖24条独立轨迹，包含侧拍、近盘沿拍摄、模糊、遮挡、正常取用、称重正负突跳、补菜、接近空盘、干净空盘、仅酱汁/碎屑/水残留。

## 快速使用

网页分包共7个ZIP：hotpot_v1_D01.zip 至 hotpot_v1_D06.zip 包含图片；hotpot_v1_标注和说明.zip 包含公共标注。将7个ZIP的内容统一解压到同一目录，得到 images/ 和各索引文件，直接打开 preview.html；使用 python3 validate.py 校验。此时不用运行 unpack.py。两个脚本只用 Python 3 标准库。

按时间读取 observations.jsonl 并加载 image_path（相对本目录）。上菜/补菜记录从 operation_log.jsonl 按时间揭示。answer_key.jsonl 是独立答案，不能提前输入模型；generation_prompts.json 和预览页答案同样不能作为模型输入。

## 内容

| 菜品 | 编号 | 条数 |
|---|---|---:|
| 小馒头 | D01 / B001–B010 | 10 |
| 南瓜饼 | D02 / K001–K010 | 10 |
| 鱼丸 | D03 / F001–F010 | 10 |
| 豆腐片 | D04 / T001–T010 | 10 |
| 腌牛肉 | D05 / M001–M010 | 10 |
| 腌鸡肉 | D06 / C001–C010 | 10 |

每种前4条是一段主要时间序列；后6条是三组“有菜→空盘/残留”的成对观测。每组不同盘号，不可跨组计算重量差。不同机位不是同一时刻的多相机重建数据。

## 字段口径

- observations.jsonl：盘号、装菜批次、菜品绑定、时间、站点、圈次、图片路径、毛重/皮重/净重、前次样本及观测净重差。毛重减皮重等于净重，单位克。
- answer_key.jsonl：模拟设定净重/变化量、事件、视觉及称重干扰、食物状态、单图能否确认空盘、期望行为。scenario_item_count 仅为生成情境设定，pixel_count_verified=false；重叠、生成偏差或模糊可能使可见个数不一致，不可用作精确计数训练真值。
- food_state：nonempty（有可取用食物）、near_empty（少量可取用食物）、clean_empty（干净空盘）、residue_only（仅残渣/酱汁/水）。残渣仍计入净重，但不当成可取用份量。
- 空盘处的 -1 克是设定为正常的±2克零点误差，保留原始值，不解释成负食物。负向异常样本 F003/C003 是大幅低读数，和零点噪声不同。
- dish_id 由盘号和批次绑定获得。空盘图片不能独立识别先前装的菜。
- camera_elevation_design_deg 是生成时的角度目标，未经几何标定。left/right 是设计键，图像未严格保证相反方位角；预览按高度类别命名。

## 数据来源与限制

图片由内置AI图像生成工具制作，完整提示词与参考关系见 generation_prompts.json。所有克数、时间和事件为人为模拟设定，并非真实门店采样或由图像实测得出。照片存在形状、机位和尺寸漂移；没有提供精确目标框、分割掩码或逐图计数真值。

本版是六菜品完整演示范围的小规模合成集，适用于管道联调和难例探索，不足以证明真实门店准确率或独立训练效果。图片共享少量生成场景和参考来源，高度相关，不应随机拆帧做训练/测试并报告泛化准确率。

重量下降不等于顾客实际吃完，也不自动等于浪费。干净空盘可包含员工移除/擦拭等模拟情形。补菜量还需要线上总余量、需求速度、后厨准备时间和在途量，本数据没有虚构确定补菜量答案。

## 后端对接

沿用仓库 modules/hotpot_dataset_v0_1 的主要文件与字段结构。后端通过 DATASET_DIR 指向解包后的本目录即可读取数据；本提交不修改后端或原夹具。

空盘相关事件在 event_since_previous_observation 统一为 removal，细节保留在 physical_event_detail。负向尖峰、正常零点负读数、仅残渣状态是新增挑战，旧后端规则及对评分数可能不完全支持；本次未宣称60条后端或视觉模型全部通过。validate.py 只验证数据完整性、一致性和图片校验值。

## 文件

observations.jsonl、answer_key.jsonl、operation_log.jsonl、dish_catalog.json、scenario_config.json、image_manifest.json、generation_prompts.json、preview.html、validate.py、unpack.py、validation_report.json。

hotpot_v1_D01.zip 到 hotpot_v1_D06.zip 各包含对应10张原始PNG，解压后合并到 images/；每包均小于25MB。公共标注在 hotpot_v1_标注和说明.zip 中。
