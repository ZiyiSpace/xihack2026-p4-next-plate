"""Validate synthetic dataset files, weights and checksums; no model evaluation."""
import json, hashlib, struct, zipfile
from pathlib import Path
from collections import Counter
from datetime import datetime

ROOT=Path(__file__).resolve().parent
def rows(name):return [json.loads(s) for s in (ROOT/name).read_text(encoding='utf-8').splitlines() if s.strip()]
def check(condition,message):
    if not condition:raise ValueError(message)
def main():
    obs=rows('observations.jsonl');answers=rows('answer_key.jsonl');ops=rows('operation_log.jsonl')
    manifest=json.loads((ROOT/'image_manifest.json').read_text(encoding='utf-8'))
    byid={r['sample_id']:r for r in obs};truth={r['sample_id']:r for r in answers};hashes={r['sample_id']:r['sha256'] for r in manifest}
    check(len(obs)==len(byid)==len(answers)==len(truth)==len(hashes)==60,'Expected exactly 60 unique observations, labels and image entries')
    check(set(byid)==set(truth)==set(hashes),'Sample keys disagree')
    check(len(set(hashes.values()))==60,'Duplicate image bytes')
    counts=Counter(r['dish_id'] for r in obs)
    check(counts=={f'D0{i}':10 for i in range(1,7)},'Expected six dishes with 10 observations each')
    check([r['timestamp'] for r in obs]==sorted(r['timestamp'] for r in obs),'Observations are not time sorted')
    modes=Counter()
    for sid,r in byid.items():
        check(datetime.fromisoformat(r['timestamp']).utcoffset() is not None,'Timezone required')
        check(r['gross_weight_g']-r['tare_g']==r['net_weight_g'],sid+': gross/tare/net mismatch')
        p=ROOT/r['image_path']
        check(p.resolve().is_relative_to(ROOT) if hasattr(p.resolve(),'is_relative_to') else str(p.resolve()).startswith(str(ROOT)+'/'),'Image escapes root')
        if p.exists():data=p.read_bytes();modes['expanded']+=1
        else:
            with zipfile.ZipFile(ROOT/'archives'/f"{r['dish_id']}.zip") as z:data=z.read(r['image_path'])
            modes['archive']+=1
        check(data[:8]==b'\x89PNG\r\n\x1a\n',sid+': not PNG')
        check(hashlib.sha256(data).hexdigest()==hashes[sid],sid+': checksum mismatch')
        check(struct.unpack('>II',data[16:24])==(r['image_width'],r['image_height']),sid+': dimensions mismatch')
        a=truth[sid]
        check(a['scenario_net_weight_g']>=0,sid+': negative scenario mass')
        check(any(o['plate_id']==r['plate_id'] and o['event_type']=='initial_load' and o['timestamp']<=r['timestamp'] for o in ops),sid+': no prior binding/load')
        if r['previous_sample_id']:
            prev=byid[r['previous_sample_id']]
            check(prev['sequence_id']==r['sequence_id'] and prev['timestamp']<r['timestamp'],sid+': incorrect prior observation')
            check(r['observed_net_delta_g']==r['net_weight_g']-prev['net_weight_g'],sid+': observed delta mismatch')
            check(a['scenario_net_delta_g']==a['scenario_net_weight_g']-truth[prev['sample_id']]['scenario_net_weight_g'],sid+': scenario delta mismatch')
        if a['sensor_condition'] in ['normal','normal_zero_noise']:
            check(abs(r['net_weight_g']-a['scenario_net_weight_g'])<=2,sid+': normal noise exceeds declared bound')
        if a['food_state']=='clean_empty':check(a['scenario_net_weight_g']==0,sid+': clean empty with mass')
        if a['food_state']=='residue_only':check(a['scenario_food_mass_g']==0 and a['scenario_residue_g']==a['scenario_net_weight_g'],sid+': residue mismatch')
    report=dict(validation='passed',scope='file_integrity_and_authored_scenario_consistency_only',samples=60,unique_images=60,
                dishes=dict(counts),sequences=len({r['sequence_id'] for r in obs}),food_states=dict(Counter(r['food_state'] for r in answers)),
                sensor_conditions=dict(Counter(r['sensor_condition'] for r in answers)),image_sources=dict(modes),
                images_reviewed_qualitatively=True,pixel_count_and_physical_mass_verified=False,model_accuracy_evaluated=False)
    (ROOT/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
