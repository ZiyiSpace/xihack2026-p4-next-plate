"""Validate the v2 scale-only synthetic test set using standard Python 3."""
import csv,json,math
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime
ROOT=Path(__file__).resolve().parent
def check(ok,msg):
    if not ok:raise ValueError(msg)
def csvrows(name):
    with (ROOT/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def jsonrows(name):return [json.loads(s) for s in (ROOT/name).read_text(encoding='utf-8').splitlines() if s.strip()]
def grade(n,c):
    if n==0:return 'L0'
    if n*5<=c:return 'L1'
    if n*2<=c:return 'L2'
    return 'L3'
def main():
    dishes=csvrows('dish_catalog.csv');records=jsonrows('weight_records.jsonl');answers=jsonrows('expected_events.jsonl');ops=jsonrows('operation_log.jsonl');boundary=csvrows('grade_boundary_cases.csv');summaries=csvrows('expected_summary.csv')
    catalog={d['dish_id']:d for d in dishes};oracle={a['record_id']:a for a in answers};inputs={r['record_id']:r for r in records};groups=defaultdict(list)
    check(len(catalog)==len(dishes)==6,'Expected six unique dishes')
    check(len({d['scale_id'] for d in dishes})==len({d['tray_id'] for d in dishes})==6,'Device bindings must be unique')
    check(len(records)==len(inputs)==len(answers)==len(oracle)==120,'Expected 120 unique records and answers')
    check(set(inputs)==set(oracle),'Input/answer IDs differ')
    check(len(boundary)==len({r['case_id'] for r in boundary})==54,'Expected 54 boundary cases')
    check(len(summaries)==6,'Expected six dish summaries')
    check(Counter(r['dish_id'] for r in records)=={d:20 for d in catalog},'Each dish needs 20 records')
    times=[datetime.fromisoformat(r['timestamp']) for r in records]
    check(times==sorted(times),'Input stream is not time sorted')
    op_map={o['record_id']:o for o in ops};check(len(op_map)==len(ops),'Duplicate operation records')
    labels={'L0':'空盘','L1':'少量','L2':'中量','L3':'充足'}
    for r in records:
        sid=r['record_id'];d=catalog[r['dish_id']];capacity=int(d['reference_full_weight_g']);net=r['net_weight_g']
        check(all(r[k]==d[k] for k in ['dish_name','scale_id','tray_id']),sid+': binding mismatch')
        check(r['tare_g']==int(d['tare_g']),sid+': tare mismatch')
        check(r['reference_full_weight_g']==capacity,sid+': capacity mismatch')
        check(isinstance(net,int) and 0<=net<=capacity,sid+': mass outside scenario range')
        check(r['gross_weight_g']-r['tare_g']==net,sid+': gross/tare/net inconsistency')
        check(math.isclose(r['remaining_ratio'],net/capacity,abs_tol=1e-12),sid+': ratio mismatch')
        check(r['remaining_grade']==grade(net,capacity)==oracle[sid]['expected_grade'],sid+': grade mismatch')
        check(r['remaining_label']==labels[r['remaining_grade']],sid+': grade label mismatch')
        check(r['source']=='synthetic_exact' and r['reading_status']=='stable',sid+': source mismatch')
        groups[r['dish_id']].append(r)
    summary_map={r['dish_id']:r for r in summaries};used_ops=set()
    for did,rows in groups.items():
        d=catalog[did];initial=int(d['initial_net_weight_g']);taken=added=count=0;prev=None
        for r in rows:
            sid=r['record_id'];a=oracle[sid]
            check(a['dish_id']==did,sid+': answer dish mismatch')
            delta=None if prev is None else r['net_weight_g']-prev['net_weight_g']
            check(r['net_delta_g']==delta,sid+': delta mismatch')
            check(r['previous_record_id']==(None if prev is None else prev['record_id']),sid+': prior record mismatch')
            check((datetime.fromisoformat(r['timestamp'])-datetime.fromisoformat(rows[0]['timestamp'])).total_seconds()==r['elapsed_seconds'],sid+': elapsed seconds mismatch')
            if prev is None:
                check(a['event_type']=='initial_load' and r['net_weight_g']==initial and r['elapsed_seconds']==0,sid+': invalid baseline')
            else:
                check(r['elapsed_seconds']>prev['elapsed_seconds'],sid+': nonincreasing time')
                expected='take' if delta<0 else 'refill' if delta>0 else 'no_change'
                check(a['event_type']==expected,sid+': event contradicts weight')
            check(a['taken_g']==(-delta if delta is not None and delta<0 else 0),sid+': taken mass mismatch')
            check(a['added_g']==(delta if delta is not None and delta>0 else 0),sid+': added mass mismatch')
            check(a['take_count_increment']==int(a['event_type']=='take'),sid+': count increment mismatch')
            if a['event_type'] in ['initial_load','refill']:
                check(sid in op_map,sid+': missing staff operation')
                op=op_map[sid];used_ops.add(sid)
                check(op['event_type']==a['event_type'] and op['timestamp']==r['timestamp'],sid+': operation event/time mismatch')
                check(all(op[k]==r[k] for k in ['dish_id','scale_id','tray_id']),sid+': operation binding mismatch')
                check(op['added_g']==a['added_g'],sid+': operation added mass mismatch')
                check(op['initial_net_g']==(initial if prev is None else None),sid+': initial operation mass mismatch')
            else:check(sid not in op_map,sid+': unexpected staff operation')
            taken+=a['taken_g'];added+=a['added_g'];count+=a['take_count_increment']
            check(a['cumulative_taken_g']==taken and a['cumulative_added_g']==added and a['cumulative_take_count']==count,sid+': cumulative mismatch')
            check(initial+added-taken==r['net_weight_g'],sid+': mass not conserved')
            prev=r
        check(rows[-1]['elapsed_seconds']==7200,did+': wrong observation window')
        s=summary_map[did]
        expected={'initial_net_g':initial,'refilled_g':added,'taken_g':taken,'final_net_g':rows[-1]['net_weight_g'],'take_count':count,'mean_take_g':taken/count,'observation_minutes':120,'takes_per_hour':count/2,'mass_balance_error_g':0}
        for key,value in expected.items():check(math.isclose(float(s[key]),value,rel_tol=1e-12,abs_tol=1e-9),did+': summary mismatch '+key)
    check(used_ops==set(op_map),'Unused staff operations')
    for b in boundary:
        n=int(b['net_weight_g']);c=int(b['reference_full_weight_g'])
        check(c==int(catalog[b['dish_id']]['reference_full_weight_g']) and 0<=n<=c,b['case_id']+': invalid boundary mass')
        check(grade(n,c)==b['expected_grade'] and b['expected_label']==labels[b['expected_grade']],b['case_id']+': boundary grade mismatch')
        check(math.isclose(float(b['remaining_ratio']),n/c,abs_tol=1e-12),b['case_id']+': boundary ratio mismatch')
    for file,rows in [('weight_records.csv',records),('expected_events.csv',answers)]:
        parsed=csvrows(file);check(len(parsed)==len(rows),file+': row count differs')
        for left,right in zip(parsed,rows):
            check(set(left)==set(right),file+': fields differ')
            for k,v in right.items():
                if isinstance(v,(int,float)):check(float(left[k])==v,file+': numeric mismatch '+k)
                else:check(left[k]==('' if v is None else v),file+': value mismatch '+k)
    report={'validation':'passed','dataset_version':'2.0-scale-only','dishes':6,'weight_records':120,'grade_boundary_cases':54,'staff_operations':len(ops),'event_counts':dict(Counter(a['event_type'] for a in answers)),'mass_balance_errors':0,'grade_errors':0,'event_errors':0,'csv_jsonl_mismatches':0,'image_files':0,'scope':'synthetic_numeric_and_label_consistency','physically_measured':False}
    (ROOT/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
